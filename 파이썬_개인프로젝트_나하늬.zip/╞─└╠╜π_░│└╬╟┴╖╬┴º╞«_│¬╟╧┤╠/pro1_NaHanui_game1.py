import math
import turtle, random

screen = turtle.Screen()

bg = turtle.Turtle()
bg.up()
bg.goto(150, -100)
img_bg = "img\\2156836.gif"
screen.addshape(img_bg)
bg.shape(img_bg)

score1 = turtle.Turtle()
score2 = turtle.Turtle()

# player1,2 사용
x1 = 0  #####
y1 = 0  #####
x2 = 400  #####
y2 = 0  #####

angle1 = 0  #####
angle2 = 180  #####
velocity1 = 50  #####
velocity2 = 50  #####

show1 = turtle.Turtle()
show2 = turtle.Turtle()

screen = turtle.Screen()


###############################################


def drawText1():  # 힘과 각도 HP 승패 출력하는 함수#
    global angle1
    global velocity1

    score1.clear()  # 지우기
    score1.hideturtle()  # 터틀 안보이게
    score1.up()
    score1.goto(-50, 400)
    score1.write("power : " + str(velocity1))
    score1.goto(-50, 380)
    score1.write("angle1 : " + str(angle1))
    if j == 10:
        score1.goto(-50, 360)
        score1.write("LOSE")
    else:
        score1.goto(-50, 360)
        score1.write("HP : " + str(100 - 10 * j))


def drawText2():  # 힘과 각도 출력하는 함수#
    global angle2
    global velocity2
    score2.clear()  # 지우기
    score2.hideturtle()  # 터틀 안보이게
    score2.up()
    score2.goto(400, 400)
    score2.write("power : " + str(velocity2))
    score2.goto(400, 380)
    score2.write("angle2 : " + str(abs(180 - angle2)))
    if i == 10:
        score2.goto(400, 360)
        score2.write("LOSE")
    else:
        score2.goto(400, 360)
        score2.write("HP : " + str(100 - 10 * i))


###############################################


player1 = turtle.Turtle()
player1.shape("turtle")
player1.color("green")

player1shoot = turtle.Turtle()
player1shoot.shape("arrow")

player2 = turtle.Turtle()
player2.up()
player2.goto(400, 0)
player2.down()
player2.shape("arrow")
player2.color("brown")
player2.left(180)

player2shoot = turtle.Turtle()
player2shoot.up()
player2shoot.goto(400, 0)
player2shoot.down()
player2shoot.shape("arrow")
player2shoot.left(180)

# 플레이어 이미지 변경
img_turtle = "img\\turtle(100x100).gif"
img_rabbit = "img\\rabbit(100x100).gif"
screen.addshape(img_turtle)
player1shoot.shape(img_turtle)
screen.addshape(img_rabbit)
player2shoot.shape(img_rabbit)

# 발사체 이미지 변경
img_tbomb = "img\\turtle1.gif"
img_rbomb = "img\\poop1.gif"
screen.addshape(img_tbomb)
player1.shape(img_tbomb)
screen.addshape(img_rbomb)
player2.shape(img_rbomb)

i = 0

j = 0

drawText1()
drawText2()


###################################################################


# player1 키설정

def turnleft1():  #####
    global angle1

    if angle1 < 85:
        player1.left(5)  # 왼쪽으로 5도 회전
        angle1 = player1.heading()  # 초기 각도
        drawText1()


def turnright1():  #####
    global angle1

    if 0 < angle1:
        player1.right(5)  # 오른쪽으로 5도 회전
        angle1 = player1.heading()  # 초기 각도
        drawText1()


def turnup1():  #####
    global velocity1

    if velocity1 < 150:  # 힘제한 최대 150까지
        velocity1 = velocity1 + 1
        drawText1()


def turndown1():  #####
    global velocity1

    if velocity1 > 50:  # 힘제한 최저 50까지
        velocity1 = velocity1 - 1
        drawText1()


###player2 키설정

def turnup2():  #####
    global velocity2

    if velocity2 < 150:  # 힘제한 최대 150까지
        velocity2 = velocity2 + 1
        drawText2()


def turndown2():  #####
    global velocity2

    if velocity2 > 50:  # 힘제한 최저 50까지
        velocity2 = velocity2 - 1
        drawText2()


def turnleft2():  #####
    global angle2

    if angle2 < 180:
        player2.left(5)  # 왼쪽으로 5도 회전
        angle2 = player2.heading()  # 초기 각도
        drawText2()


def turnright2():  #####
    global angle2

    if 5 < angle2:
        player2.right(5)  # 오른쪽으로 5도 회전
        angle2 = player2.heading()  # 초기 각도
        drawText2()


# 키설정 입력

def keyset(flag):  ######
    if flag == 1:
        screen.onkey(turnleft1, "a")
        screen.onkey(turnright1, "d")
        screen.onkey(turnup1, "w")
        screen.onkey(turndown1, "s")
        screen.onkey(fire1, "Escape")
        screen.onkey(None, "Left")
        screen.onkey(None, "Right")
        screen.onkey(None, "Up")
        screen.onkey(None, "Down")
        screen.onkey(None, "space")
    else:
        screen.onkey(turnleft2, "Left")
        screen.onkey(turnright2, "Right")
        screen.onkey(turnup2, "Up")
        screen.onkey(turndown2, "Down")
        screen.onkey(fire2, "space")
        screen.onkey(None, "a")
        screen.onkey(None, "d")
        screen.onkey(None, "w")
        screen.onkey(None, "s")
        screen.onkey(None, "Escape")


###############################################################
# 발사함수


def fire1():
    player1.shapesize(2)
    global x1
    global y1
    global velocity1
    global angle1

    angle1 = player1.heading()
    vx = velocity1 * math.cos(angle1 * 3.14 / 180.0)  # 도->라디안
    vy = velocity1 * math.sin(angle1 * 3.14 / 180.0)  # 도->라디안

    while True:
        vy = vy - 10
        x1 = x1 + vx
        y1 = y1 + vy
        player1.goto(x1, y1)  # 거북이 쭉가기
        if y1 < 0:  # 땅
            x1 -= vx
            break

    global i

    if -1000 <= x1 <= 1000 and -1000 <= y1 <= 1000:

        # 맞췄을때 발생되는 상황
        if i == 0:
            i += 1
            player1.reset()
            player1shoot.reset()
            player1.color("green")

        elif i == 1:
            i += 1
            player1.reset()
            player1shoot.reset()
            player1.color("green")

        elif i == 2:
            i += 1
            player1.reset()
            player1shoot.reset()
            player1.color("green")

        elif i == 3:
            i += 1
            player1.reset()
            player1shoot.reset()
            player1.color("green")

        elif i == 4:
            i += 1
            player1.reset()
            player1shoot.reset()
            player1.color("green")

        elif i == 5:
            i += 1
            player1.reset()
            player1shoot.reset()
            player1.color("green")

        elif i == 6:
            i += 1
            player1.reset()
            player1shoot.reset()
            player1.color("green")

        elif i == 7:
            i += 1
            player1.reset()
            player1shoot.reset()
            player1.color("green")

        elif i == 8:
            i += 1
            player1.reset()
            player1shoot.reset()
            player1.color("green")

        elif i == 9:
            i += 1
            score1.reset()
            score1.hideturtle()
            score1.up()
            score1.goto(100, 200)
            score1.write("LOSE")
            player1.color("green")

        drawText2()

    # 못맞춤 ㅠㅠ
    else:
        player1.reset()

    keyset(2)
    x1 = 0  ##수정한 부분(고생시킴)
    y1 = 0


def fire2():
    player2.shapesize(2)

    global x2
    global y2
    global velocity2
    global angle2

    angle2 = player2.heading()

    vx = velocity2 * math.cos(angle2 * 3.14 / 180.0)  # 도->라디안
    vy = velocity2 * math.sin(angle2 * 3.14 / 180.0)  # 도->라디안
    while True:

        vy = vy - 10
        x2 = x2 + vx
        y2 = y2 + vy
        player2.goto(x2, y2)  # 거북이 쭉가기

        if y2 < 0:
            x2 -= vx
            break

    global j

    if -1000 <= x2 <= 1000 and -1000 <= y2 <= 1000:

        if j == 0:
            j += 1
            player2.reset()
            player2.up()
            player2.goto(400, 0)
            player2.down()
            player2shoot.reset()
            player2.color("brown")
            player2shoot.up()
            player2shoot.goto(400, 0)
            player2shoot.down()
            player2.left(180)
            player2shoot.left(180)

        elif j == 1:
            j += 1
            player2.reset()
            player2.up()
            player2.goto(400, 0)
            player2.down()
            player2shoot.reset()
            player2.color("brown")
            player2shoot.up()
            player2shoot.goto(400, 0)
            player2shoot.down()
            player2.left(180)
            player2shoot.left(180)

        elif j == 2:
            j += 1
            player2.reset()
            player2.up()
            player2.goto(400, 0)
            player2.down()
            player2shoot.reset()
            player2.color("brown")
            player2shoot.up()
            player2shoot.goto(400, 0)
            player2shoot.down()
            player2.left(180)
            player2shoot.left(180)

        elif j == 3:
            j += 1
            player2.reset()
            player2.up()
            player2.goto(400, 0)
            player2.down()
            player2shoot.reset()
            player2.color("brown")
            player2shoot.up()
            player2shoot.goto(400, 0)
            player2shoot.down()
            player2.left(180)
            player2shoot.left(180)

        elif j == 4:
            j += 1
            player2.reset()
            player2.up()
            player2.goto(400, 0)
            player2.down()
            player2shoot.reset()
            player2.color("brown")
            player2shoot.up()
            player2shoot.goto(400, 0)
            player2shoot.down()
            player2.left(180)
            player2shoot.left(180)

        elif j == 5:
            j += 1
            player2.reset()
            player2.up()
            player2.goto(400, 0)
            player2.down()
            player2shoot.reset()
            player2.color("brown")
            player2shoot.up()
            player2shoot.goto(400, 0)
            player2shoot.down()
            player2.left(180)
            player2shoot.left(180)

        elif j == 6:
            j += 1
            player2.reset()
            player2.up()
            player2.goto(400, 0)
            player2.down()
            player2shoot.reset()
            player2.color("brown")
            player2shoot.up()
            player2shoot.goto(400, 0)
            player2shoot.down()
            player2.left(180)
            player2shoot.left(180)

        elif j == 7:
            j += 1
            player2.reset()
            player2.up()
            player2.goto(400, 0)
            player2.down()
            player2shoot.reset()
            player2shoot.color("pink")
            player2shoot.up()
            player2shoot.goto(400, 0)
            player2shoot.down()
            player2.left(180)
            player2shoot.left(180)


        elif j == 8:
            j += 1
            player2.reset()
            player2.up()
            player2.goto(400, 0)
            player2.down()
            player2shoot.reset()
            player2shoot.color("pink")
            player2shoot.up()
            player2shoot.goto(400, 0)
            player2shoot.down()
            player2.left(180)


        elif j == 9:
            j += 1
            player2.left(180)
            player2shoot.left(180)
            player2shoot.color("pink")
            score2.reset()
            score2.hideturtle()
            score2.up()
            score2.goto(0, 200)
            score2.write("LOSE")

        drawText1()

    else:
        player2.reset()
        player2.up()
        player2.goto(400, 0)
        player2.down()
        player2.shape("turtle")
        player2.color("red")
        player2.left(180)

    keyset(1)
    x2 = 400
    y2 = 0


screen.onkey(turnleft1, "a")
screen.onkey(turnright1, "d")
screen.onkey(turnup1, "w")
screen.onkey(turndown1, "s")
screen.onkey(fire1, "Escape")

screen.listen()

turtle.mainloop()
turtle.bye()