from tkinter import *
import tkinter as tk

window = tk.Tk()
window.geometry('1600x1000')                                                #초기 화면 크기 설정
window.title("나하늬")                                                  #화면 제목 설정

graph1 = PhotoImage(file = "C:\\Users\\ASIA-04\\Desktop\\img1.gif")
graph2 = PhotoImage(file = "C:\\Users\\ASIA-04\\Desktop\\img2 (1).gif")
graph3 = PhotoImage(file = "C:\\Users\\ASIA-04\\Desktop\\img3.gif")

label = Label(window, image = graph1)                                       #최초 화면 graph1 사진

def change_graph1():
    label.config(image = graph1)
def change_graph2():
    label.config(image = graph2)
def change_graph3():
    label.config(image = graph3)

check1 = IntVar()
check2 = IntVar()
check3 = IntVar()

b1 = Button(window, text="국내평균해수면, CO2 총배출량",command=change_graph1)
b2 = Button(window, text="CO2 총배출량, 석탄 화력 발전비율",command=change_graph2)
b3 = Button(window, text="CO2 총배출량, 기온의 연평균 (℃)",command=change_graph3)

label.pack()
b1.pack()
b2.pack()
b3.pack()

window.mainloop()