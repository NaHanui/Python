from matplotlib import pyplot as plt
import csv
from matplotlib import font_manager,rc

font_name = font_manager.FontProperties(fname="C:\Windows\Fonts\malgun.ttf").get_name()                     # 한글오류로 인하여 폰트 불러오기
rc("font",family=font_name)

infile = open("C:\\Users\\ASIA-04\\Desktop\\6_17_list2.py_220329\\total_total_.csv","r",encoding="cp949")   # 엑셀 파일 불러오기
data = csv.reader(infile)                                                                                   # csv 읽기

x=[]
y1=[]
y2=[]
y3=[]
y4=[]

for line in data:                                                                                           # 데이터 리스트로 쪼개기
    x.append(float(line[0]))
    y1.append(float(line[1]))
    y2.append(float(line[2]))
    y3.append(float(line[3]))
    y4.append(float(line[4]))

def call_y(y):                                                                                              #입력 값에 따른 리스트 불러오기
    if y =="y1":
        y=y1
        return y
    elif y == "y2":
        y=y2
        return y
    elif y == "y3":
        y=y3
        return y
    elif y == "y4":
        y=y4
        return y
def callname(y):                                                                                            #입력 값에 따른 그래프 축 제목
    name_list = ["국내평균해수면", "CO2 총배출량(Gg CO2eq)", "석탄 화력 발전비율", "최고기온의 연평균 (℃)"]
    if y =="y1":

        return name_list[0]
    elif y == "y2":

        return name_list[1]
    elif y == "y3":

        return name_list[2]
    elif y == "y4":

        return name_list[3]

while True:                                                                                                 # 그래프 입력값에 따른 그래프 만들기

    a = input("입력해주세요 : ")


    a_list=a.split(" ")

    if len(a_list) != 2:                                                                                    # 입력값이 2개가 아니면 입력부터
        print("입력값 사이에 스페이스바 눌러 다시 입력해주세요!!!! EX)y1 y2")

    else:                                                                                                   # 입력값 순차적으로 불러오기
        y1_ = a_list[0]
        y2_ = a_list[1]
        print(a_list)
        print(y1_)


        c_list=["y1","y2","y3","y4"]


        if y1_ in c_list:                                                                                   # 입력값이 y1,y2,y3,y4 맞으면
            if y2_ in c_list:                                                                               #plt.subplots()은 figure 및 axes 객체를 포함하는 튜플을 반환하는 함수
                fig, ax1 = plt.subplots()                                                                   #첫 번째 개체는 그림 개체 여야하고 다른 하나는 하위 그림 개체 그룹이어야합니다.
                ax1.set_xlabel('연도')                                                                       #x축 이름
                ax1.set_ylabel(callname(y1_))                                                               #y축 이름
                ax1.plot(x, call_y(y1_), color='green', label=callname(y1_))                                #그래프 그리기
                ax1.legend(loc='upper right')                                                               #legend(범례)는 그래프에 표시하기 위한 텍스트, 오른쪽 위
                ax2 = ax1.twinx()                                                                           #ax1.twinx()는 ax1과 x축을 공유하는 새로운 Axes 객체를 만듭니다.
                if y2_ == "y4":                                                                             #위와 동일 함수 이용하여 그래프 작성
                    plt.ylim([12.1,14])
                ax2.set_ylabel(callname(y2_))
                ax2.plot(x, call_y(y2_), color='deeppink', label=callname(y2_))
                ax2.legend(loc='lower right')
                plt.show()
                infile.close()
                break                                                                                       #그래프가 그려진다면 while문 탈출
            else:                                                                                           ## 입력값이 y1,y2,y3,y4 아니라면 다시 입력
                print("다시 입력해주세요!!!! EX)y1 y2")
                continue
        else :                                                                                              ##입력값이 y1,y2,y3,y4 아니라면 다시 입력
            print("다시 입력해주세요!!!! EX)y1 y2")
            continue